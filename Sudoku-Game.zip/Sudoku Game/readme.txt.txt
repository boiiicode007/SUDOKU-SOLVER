This directory contains two files:
1. GUI.py
2. solver.py

To run the game simply run the GUI.py file from IDLE or the command line.

Note: You require pygame to play this game, you can watch this video to learn how to download it
https://www.youtube.com/watch?v=AdUZArA-kZw